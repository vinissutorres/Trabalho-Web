function openSidebar() {
    let el = document.querySelector('#player-history');
    el.classList.toggle('open');
}

function closeSidebar() {
    let el = document.querySelector('#player-history');
    el.classList.toggle('open');
}